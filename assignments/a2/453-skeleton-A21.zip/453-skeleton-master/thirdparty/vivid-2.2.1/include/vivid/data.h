#pragma once

#include "vivid/data/blue-yellow.h"
#include "vivid/data/cool-warm.h"
#include "vivid/data/hsl-pastel.h"
#include "vivid/data/hsl.h"
#include "vivid/data/inferno.h"
#include "vivid/data/magma.h"
#include "vivid/data/plasma.h"
#include "vivid/data/rainbow.h"
#include "vivid/data/turbo.h"
#include "vivid/data/viridis.h"
#include "vivid/data/vivid.h"
#include "vivid/data/xterm.h"
